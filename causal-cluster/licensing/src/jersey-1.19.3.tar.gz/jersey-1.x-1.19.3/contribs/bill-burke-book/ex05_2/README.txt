
This project is a simple example showing usage of JAX-RS injeciton annotations.

System Requirements:
====================
- Maven 2.0.9 or higher

Building the project:
====================
1. In root directoy

mvn jetty:run

This will build a WAR and run it with embedded Jetty

Then open browser and go to:

http://localhost:9095

Submit form and follow links.
