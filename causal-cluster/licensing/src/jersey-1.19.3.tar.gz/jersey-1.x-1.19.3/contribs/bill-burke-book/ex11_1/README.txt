
This project is an example of using JAX-RS, EJB, and JPA all together in one application through a JAX-RS
portable way.

System Requirements:
====================
- Maven 2.0.9 or higher

Building the project:
====================
1. Start a JBoss 5.1.0.GA instance in the background
2. In root directoy

mvn clean install

This will build an EAR and run the testsuite within ear/src/test/...
